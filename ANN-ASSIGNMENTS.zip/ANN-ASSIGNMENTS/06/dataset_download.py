import kagglehub

# Download latest version
path = kagglehub.dataset_download("neehakurelli/google-speech-commands")

print("Path to dataset files:", path)